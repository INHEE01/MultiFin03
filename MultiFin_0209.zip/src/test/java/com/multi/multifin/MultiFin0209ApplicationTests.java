package com.multi.multifin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiFin0209ApplicationTests {

	@Test
	void contextLoads() {
	}

}
